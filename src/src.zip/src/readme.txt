# I made my own cert.pem & key.pem pair
# in ./data directory, html files exist.

# for compile, i used clang and openssl is in /opt/homebrew/opt/openssl/
# gcc would be okay.
# if you can't compile, you should download openssl library and
# modify bash instruction for your own openssl path below.
bash:: clang -o server server.c -I/opt/homebrew/opt/openssl@3/include -L/opt/homebrew/opt/openssl@3/lib -lssl -lcrypto
bash: ./server 8080 ./data

# in terminal,
bash: curl -k https://localhost:8080/

# then, can get the content of ticketing.html code
# so, i think the problem is using my cert.pem in chrome or safari,,
# but i don't know how


Todo::
    1. solving above problem.
    2. (optional) store database in mysql(locally) and get data by query
    3. is there more idea?