#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

// Function to get the file extension
const char* get_file_extension(const char* filename) {
    const char* dot = strrchr(filename, '.');
    return (!dot || dot == filename) ? "" : dot + 1;
}

// Function to determine content type based on the file extension
const char* get_content_type(const char* extension) {
    if (strcmp(extension, "html") == 0 || strcmp(extension, "htm") == 0)
        return "text/html; charset=UTF-8";
    if (strcmp(extension, "js") == 0)
        return "application/javascript";
    if (strcmp(extension, "png") == 0)
        return "image/png";
    if (strcmp(extension, "jpg") == 0 || strcmp(extension, "jpeg") == 0)
        return "image/jpeg";
    return "application/octet-stream";
}

// Function to handle 404 errors
void send_404(SSL* ssl) {
    const char* response = "HTTP/1.1 404 Not Found\r\n"
                           "Connection: close\r\n"
                           "Content-Type: text/plain\r\n"
                           "\r\n"
                           "File Not Found\r\n";
    SSL_write(ssl, response, strlen(response));
}

// Function to serve static files without Content-Length (Connection: close)
void serve_file(SSL* ssl, const char* filePath) {
    int file = open(filePath, O_RDONLY);
    if (file < 0) {
        send_404(ssl);
        return;
    }

    struct stat fileStat;
    if (fstat(file, &fileStat) < 0) {
        perror("Error getting file size");
        close(file);
        send_404(ssl);
        return;
    }

    const char* extension = get_file_extension(filePath);
    const char* contentType = get_content_type(extension);

    // 여기서는 Content-Length를 명시하지 않고 Connection: close로 전송
    // 클라이언트는 서버가 연결을 끊으면 응답 끝을 인식
    char responseHeader[BUFFER_SIZE];
    int headerLength = snprintf(responseHeader, BUFFER_SIZE,
        "HTTP/1.1 200 OK\r\n"
        "Connection: close\r\n"
        "Content-Type: %s\r\n"
        "\r\n",
        contentType);

    if (SSL_write(ssl, responseHeader, headerLength) <= 0) {
        perror("Error writing header to client");
        close(file);
        return;
    }

    char buffer[BUFFER_SIZE];
    ssize_t bytesRead;

    while ((bytesRead = read(file, buffer, BUFFER_SIZE)) > 0) {
        int written = SSL_write(ssl, buffer, bytesRead);
        if (written <= 0) {
            perror("Error writing to client");
            break;
        }
    }

    close(file);
    // 여기서 Connection: close로 했으므로 SSL_shutdown 후 소켓 닫으면 끝.
}

// Function to process client requests
void handle_client_request(SSL* ssl, const char* directory, int clientSockets[]) {
    char buffer[BUFFER_SIZE];
    int bytes = SSL_read(ssl, buffer, sizeof(buffer) - 1);

    if (bytes <= 0) {
        perror("Error reading from client");
        return;
    }

    buffer[bytes] = '\0'; // Null-terminate the request string

    // Parse the HTTP request to get the requested file path
    char method[16], path[256], protocol[16];
    sscanf(buffer, "%s %s %s", method, path, protocol);

    if (strcmp(method, "GET") != 0) {
        send_404(ssl); // Only support GET method for simplicity
        return;
    }

    // "/" 경로로 접근 시 ticketing.html 제공
    if (strcmp(path, "/") == 0) {
        strcpy(path, "/ticketing.html");
    }

    // Construct the full file path
    char filePath[512];
    snprintf(filePath, sizeof(filePath), "%s%s", directory, path);

    // Serve the requested file
    serve_file(ssl, filePath);
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <port> <directory>\n", argv[0]);
        exit(1);
    }

    // OpenSSL initialization
    OPENSSL_init_ssl(OPENSSL_INIT_LOAD_SSL_STRINGS | OPENSSL_INIT_LOAD_CRYPTO_STRINGS, NULL);
    OPENSSL_init_crypto(OPENSSL_INIT_LOAD_CONFIG, NULL);

    SSL_CTX* sslContext = SSL_CTX_new(TLS_server_method());
    if (sslContext == NULL) {
        perror("Error creating SSL context");
        exit(1);
    }

    if (SSL_CTX_use_certificate_file(sslContext, "./cert.pem", SSL_FILETYPE_PEM) <= 0) {
        perror("Error loading certificate");
        exit(1);
    }

    if (SSL_CTX_use_PrivateKey_file(sslContext, "./key.pem", SSL_FILETYPE_PEM) <= 0) {
        perror("Error loading private key");
        exit(1);
    }

    if (!SSL_CTX_check_private_key(sslContext)) {
        perror("Private key does not match certificate");
        exit(1);
    }

    int port = atoi(argv[1]);
    const char* directory = argv[2];

    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("Error creating socket");
        exit(1);
    }

    struct sockaddr_in serverAddress = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = htons(port)
    };

    // SO_REUSEADDR 설정 (선택 사항)
    int opt = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
        perror("Error binding socket");
        close(serverSocket);
        exit(1);
    }
    printf("Server successfully bound to port %d\n", port);

    if (listen(serverSocket, 5) < 0) {
        perror("Error listening on socket");
        close(serverSocket);
        exit(1);
    }

    fd_set readfds;
    int clientSockets[MAX_CLIENTS] = {0};

    printf("Server listening on port %d...\n", port);

    while (1) {
        FD_ZERO(&readfds);
        FD_SET(serverSocket, &readfds);
        int maxfd = serverSocket;

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clientSockets[i] > 0)
                FD_SET(clientSockets[i], &readfds);
            if (clientSockets[i] > maxfd)
                maxfd = clientSockets[i];
        }

        if (select(maxfd + 1, &readfds, NULL, NULL, NULL) < 0) {
            if (errno != EINTR) {
                perror("Error in select");
                break;
            }
        }

        if (FD_ISSET(serverSocket, &readfds)) {
            int newSocket = accept(serverSocket, NULL, NULL);
            if (newSocket < 0) {
                perror("Error accepting connection");
                continue;
            }

            SSL* ssl = SSL_new(sslContext);
            SSL_set_fd(ssl, newSocket);

            if (SSL_accept(ssl) <= 0) {
                ERR_print_errors_fp(stderr);
                SSL_shutdown(ssl);
                SSL_free(ssl);
                close(newSocket);
                continue;
            }

            handle_client_request(ssl, directory, clientSockets);

            // 응답 완료 후 연결 종료
            SSL_shutdown(ssl);
            SSL_free(ssl);
            close(newSocket);
        }
    }

    close(serverSocket);
    SSL_CTX_free(sslContext);
    return 0;
}
